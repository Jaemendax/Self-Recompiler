#pragma once

//{{
void example();
int example2(int x);
void example3(void);
int add(int x, int y);
//}}