#include "invoker.hpp"

const noreturn_t noreturn{};
