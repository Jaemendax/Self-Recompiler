#include "userfuncs.hpp"

#include <iostream>

using namespace std;


void example()
{
	cout << "example() called";
}

int example2(int x)
{
	return x;
}

void example3(void)
{
	cout << "example3() called.";
}

int add(int x, int y)
{
	return x + y;
}
